<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class IncidentReasonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // require(__DIR__ . '/data/incident.php'); //dd($arr_positive,$arr_negative);
        require(__DIR__ . '/data/incident2.php'); //dd($arr_positive,$arr_negative);
        $status_valoration = true;

        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        DB::table('incident_descriptions')->truncate();
        DB::table('incident_reasons')->truncate();

        foreach ($arr_positive as $category => $reazons) {
            foreach ($reazons as $reazon => $descriptions_arr) {
                $arr = [
                    'name' => $reazon,
                    'status_valoration' => $status_valoration,
                    'category' => $category,
                ];
                $reason_id = DB::table('incident_reasons')->insertGetId($arr);
                // $reason_id = 100;
                foreach ($descriptions_arr as $ambit => $descriptions) {
                    foreach ($descriptions as $k => $description) {
                        $arr = [
                            'reason_id' => $reason_id,
                            'name' => $description,
                            'ambit' => $ambit,
                        ];//dd($arr);
                        DB::table('incident_descriptions')->insert($arr);
                    }
                }
            }
        }

        $status_valoration = false;
        foreach ($arr_negative as $category => $reazons) { //dd($category);
            foreach ($reazons as $reazon => $descriptions_arr) {
                $arr = [
                    'name' => $reazon,
                    'status_valoration' => $status_valoration,
                    'category' => $category,
                ];
                $reason_id = DB::table('incident_reasons')->insertGetId($arr);
                // $reason_id = 100;
                foreach ($descriptions_arr as $ambit => $descriptions) {
                    foreach ($descriptions as $k => $description) {
                        $arr = [
                            'reason_id' => $reason_id,
                            'name' => $description,
                            'ambit' => $ambit,
                        ];//dd($arr);
                        DB::table('incident_descriptions')->insert($arr);
                    }
                }
            }
        }
    }
}
