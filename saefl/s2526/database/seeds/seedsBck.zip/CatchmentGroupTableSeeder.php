<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CatchmentGroupTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        // DB::table('catchment_groups')->truncate();
        $datas = [
            [ 'grado_id'=>1,'name'=>"Grupo A 1er grado",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>1,'name'=>"Grupo B 1er grado",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>1,'name'=>"Grupo C 1er grado",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>1,'name'=>"Grupo D 1er grado",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>1,'name'=>"Grupo E 1er grado",'max'=> 50,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>2,'name'=>"Grupo A 2do grado",'max'=> 2,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>2,'name'=>"Grupo B 2do grado",'max'=> 2,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>3,'name'=>"Grupo A 3er grado",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>3,'name'=>"Grupo B 3er grado",'max'=> 50,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>4,'name'=>"Grupo A 4to grado",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>4,'name'=>"Grupo B 4to grado",'max'=> 50,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>5,'name'=>"Grupo A 5to grado",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>5,'name'=>"Grupo B 5to grado",'max'=> 50,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>6,'name'=>"Grupo A 6to grado",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>6,'name'=>"Grupo B 6to grado",'max'=> 50,'min'=> 10,'status_active'=>true],

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            [ 'grado_id'=>12,'name'=>"Grupo A 1er Año",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>12,'name'=>"Grupo B 1er Año",'max'=> 50,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>13,'name'=>"Grupo A 2do año",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>13,'name'=>"Grupo B 2do año",'max'=> 50,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>14,'name'=>"Grupo A 3er año",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>14,'name'=>"Grupo B 3er año",'max'=> 50,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>15,'name'=>"Grupo A 4to año",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>15,'name'=>"Grupo B 4to año",'max'=> 50,'min'=> 10,'status_active'=>true],

            [ 'grado_id'=>16,'name'=>"Grupo A 5to año",'max'=> 50,'min'=> 10,'status_active'=>true],
            [ 'grado_id'=>16,'name'=>"Grupo B 5to año",'max'=> 50,'min'=> 10,'status_active'=>true],
        ] ;
        DB::table('catchment_groups')->insert($datas);
    }
}
