<?php

use Illuminate\Database\Seeder;

use Faker\Generator as Faker;
use Illuminate\Support\Carbon;

class RegistroPagoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $file = "registro_pagos";
        $fecha = "2019-09-21";
        $csvFile = public_path().'/csv/'.$fecha.'/'.$file.'.csv';
        $arr_data = csv_to_array($csvFile,",");
        DB::table($file)->insert($arr_data);
    }
}
