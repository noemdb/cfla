<?php

use Illuminate\Database\Seeder;

class TautoridadTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tautoridads')->insert([ // ID = 1
            'name' => 'REPRESENTATE LEGAL',
        ]);
        DB::table('tautoridads')->insert([ // ID = 2
            'name' => 'ADMINISTRADOR',
        ]);
        DB::table('tautoridads')->insert([ // ID = 3
            'name' => 'JEFE DE CONTROL DE ESTUDIO',
        ]);        
        DB::table('tautoridads')->insert([ // ID = 3
            'name' => 'DIRECTOR DE ADMINISTRACIÓN',
        ]);
    }
}
