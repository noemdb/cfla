<?php

use Illuminate\Database\Seeder;

class CollPromiseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
