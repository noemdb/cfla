<?php

use Illuminate\Database\Seeder;

class SelectOptTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        require (__DIR__ . '/include/users.php');
        require (__DIR__ . '/include/rols.php');  
        require (__DIR__ . '/include/tasks.php');        
        require (__DIR__ . '/include/alerts.php');
        require (__DIR__ . '/include/messeges.php');
        require (__DIR__ . '/include/settings.php');        
    }
}
