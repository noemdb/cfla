<?php

use Illuminate\Database\Seeder;

class TinscripcionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tinscripcions')->insert([
            'name' => 'NUEVO',
        ]);
        DB::table('tinscripcions')->insert([
            'name' => 'REINSCRITO',
        ]);
        DB::table('tinscripcions')->insert([
            'name' => 'REINCORPORADO',
        ]);
        DB::table('tinscripcions')->insert([
            'name' => 'TRASLADO',
        ]);
    }
}
