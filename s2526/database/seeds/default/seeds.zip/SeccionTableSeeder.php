<?php

use Illuminate\Database\Seeder;

class SeccionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('seccions')->insert([
            'grado_id' => '1',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '1',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '2',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '2',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '3',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '3',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '4',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '4',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '5',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '5',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '6',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '6',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '7',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '7',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '8',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '8',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '9',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '9',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '10',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '10',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '11',
            'name' => 'A',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
        DB::table('seccions')->insert([
            'grado_id' => '11',
            'name' => 'B',
            'description' => 'A',
            'amount_student' => '40',
            'observation' => '',
            'status_active' => 'true'
        ]);
    }
}
