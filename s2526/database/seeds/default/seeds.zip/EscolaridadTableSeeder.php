<?php

use Illuminate\Database\Seeder;

class EscolaridadTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('escolaridads')->insert([
            'name' => 'REGUSLAR',
            'code' => 'RG',
        ]);
        DB::table('escolaridads')->insert([
            'name' => 'REPITIENTE',
            'code' => 'RP',
        ]);
        DB::table('escolaridads')->insert([
            'name' => 'MATERIA PENDIENTE',
            'code' => 'MP',
        ]);
        DB::table('escolaridads')->insert([
            'name' => 'DIFERIDO',
            'code' => 'DI',
        ]);        
    }
}
