<?php

use Illuminate\Database\Seeder;

class ReciboCashSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
