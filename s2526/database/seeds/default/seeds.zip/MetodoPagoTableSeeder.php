<?php

use Illuminate\Database\Seeder;

class MetodoPagoTableSeeder extends Seeder
{
    /**
     * Run the database seeds. Depósito, transferencia electrónica, punto de venta o crédito a favor
     *
     * @return void
     */
    public function run()
    {
        DB::table('metodo_pagos')->insert([
            'name' => "Crédito a favor",
            'code' => "CAF",
            'observations' => "",
        ]);
        DB::table('metodo_pagos')->insert([
            'name' => "Depósito",
            'code' => "DEP",
            'observations' => "",
        ]);
        DB::table('metodo_pagos')->insert([
            'name' => "Transferencia Electrónica",
            'code' => "TR.ELEC",
            'observations' => "",
        ]);
        DB::table('metodo_pagos')->insert([
            'name' => "Punto de Venta",
            'code' => "POSV",
            'observations' => "",
        ]);
		DB::table('metodo_pagos')->insert([
            'name' => "Pago Móvil - Bancaribe",
            'code' => "PM-Bancaribe",
            'observations' => "",
        ]);
        
    }
}
