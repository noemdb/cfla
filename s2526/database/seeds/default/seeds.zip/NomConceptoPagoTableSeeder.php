<?php

use Illuminate\Database\Seeder;

class NomConceptoPagoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('nom_concepto_pagos')->insert([
            'name' => "MATRÍCULA",
        ]);
        DB::table('nom_concepto_pagos')->insert([
            'name' => "SEGURO ESCOLAR",
        ]);
        DB::table('nom_concepto_pagos')->insert([
            'name' => "DEUDA PERIODOS ANTERIORES",
        ]);
        //DB::table('nom_concepto_pagos')->insert([
            //'name' => "DIFERENCIAL",
        //]);
        DB::table('nom_concepto_pagos')->insert([
            'name' => "ESPECIALES",
        ]);
        $arr = ['ENERO',"FEBRERO","MARZO","ABRIL","MAYO","JUNIO","JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE",];
        for ($i=0; $i < count($arr); $i++) {         
            DB::table('nom_concepto_pagos')->insert([
                'name' => $arr[$i],
            ]);
        }
        //DB::table('nom_concepto_pagos')->insert([
            //'name' => "EXTRAORDINARIOS",
        //]);
        //DB::table('nom_concepto_pagos')->insert([
            //'name' => "OTROS",
        //]);        
    }
}
