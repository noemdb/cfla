<?php

use Illuminate\Database\Seeder;

class DebtpaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
