<?php

use Illuminate\Database\Seeder;

class CollPolicalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
