<?php

use Illuminate\Database\Seeder;

class PescolarTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('pescolars')->insert([
            'name' =>'2019-2020',
            'institucion_id' =>'1',
            'description' => "Período Escolar 2019 - 2020",
            'finicial' => "2019-09-01",
            'ffinal' => "2020-07-31"
        ]);
    }
}
