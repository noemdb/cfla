<?php

use Illuminate\Database\Seeder;

class PeducativoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('peducativos')->insert([
            'pescolar_id' => '1',
            'name' => 'EDUCACION INICIAL',
            'description' => 'EDUCACION INICIAL',
            'order' => '1',
            'status_active' => 'false'
        ]);
        DB::table('peducativos')->insert([
            'pescolar_id' => '1',
            'name' => 'EDUCACION PRIMARIA',
            'description' => 'EDUCACION PRIMARIA',
            'order' => '2',
            'status_active' => 'true'
        ]);
        DB::table('peducativos')->insert([
            'pescolar_id' => '1',
            'name' => 'EDUCACION MEDIA GENERAL',
            'description' => 'EDUCACION MEDIA GENERAL',
            'order' => '2',
            'status_active' => 'true'
        ]);
    }
}