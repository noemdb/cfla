<?php

use Illuminate\Database\Seeder;

use App\Models\app\Pescolar\Profesor;
use Illuminate\Support\Carbon;

class UsersProfesorsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        // php artisan db:seed --class=UsersProfesorsTableSeeder
        $profesors = Profesor::active('true')->get();

        foreach ($profesors as $profesor) {

            $arr_name = explode(" ", $profesor->name);
            $arr_lastname = explode(" ", $profesor->lastname);
            $str_ci = substr($profesor->ci_profesor,-2,2);

            $user = $arr_name[0][0].$arr_lastname[0].$str_ci;
            $email = (!empty($profesor->email)) ? $profesor->email : $user.'@saefl.test' ;
            $id = $profesor->id;

            $id = DB::table('users')->insertGetId([
                'username' => $user,
                // 'password' => bcrypt($profesor->ci_profesor),
                'password' => bcrypt('profesor'),
                'email' => $email,
                'is_active' => 'enable',
                'created_at'=> Carbon::now(),
                'remember_token' => str_random(10),
            ]);
            DB::table('profiles')->insert([
                'firstname' => $profesor->name,
                'lastname' => $profesor->lastname,
                'url_img' => "images/avatar/user_default.png",
                'user_id' => $id,
                'created_at' => Carbon::now(),
            ]);
            DB::table('rols')->insert([
                'area' => "PROFESORADO",
                'rol' => "PROFESOR",
                'descripcion' => "Profesor de la institución",
                'finicial' => "20190901",
                'ffinal' => "20200901",
                'user_id' => $id,
                'created_at' => Carbon::now(),
            ]);
        }
    }
}
