<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);

        // $this->call(UsersAdminTableSeeder::class);
        $this->call(UsersTableSeeder::class);
        // $this->call(ProfilesTableSeeder::class);
        // $this->call(RolsTableSeeder::class);
        // $this->call(TaskTableSeeder::class);
        // $this->call(MessegeTableSeeder::class);
        // $this->call(AlertTableSeeder::class);
        // $this->call(LoginoutTableSeeder::class);
        // $this->call(LogdbTableSeeder::class);
        $this->call(SettingTableSeeder::class);
        $this->call(SelectOptTableSeeder::class);
        
        $this->call(InstitucionTableSeeder::class);
        $this->call(PlanPagoTableSeeder::class);
        $this->call(RepresentantTableSeeder::class);        
        $this->call(TypeCisTableSeeder::class);
        $this->call(EstudiantTableSeeder::class);

        $this->call(PescolarTableSeeder::class);
        $this->call(TautoridadTableSeeder::class);
        $this->call(AutoridadTableSeeder::class);
        $this->call(BancoTableSeeder::class);
        $this->call(PeducativoTableSeeder::class);
        $this->call(PestudioTableSeeder::class);
        $this->call(GradoTableSeeder::class);
        $this->call(SeccionTableSeeder::class);
        $this->call(TinscripcionTableSeeder::class);        
        $this->call(EscolaridadTableSeeder::class);        
        $this->call(InscripcionTableSeeder::class);        
        $this->call(AdministrativaTableSeeder::class);        
                
        $this->call(CuentaXPagarTableSeeder::class);        
        $this->call(NomConceptoPagoTableSeeder::class);        
        $this->call(ConceptoPagoTableSeeder::class);        
        $this->call(DescuentoTableSeeder::class);        
        $this->call(MetodoPagoTableSeeder::class);        
        $this->call(PlanBeneficoTableSeeder::class);       
        $this->call(RegistroPagoTableSeeder::class);        
        $this->call(IngresoTableSeeder::class);        
        $this->call(PagoTableSeeder::class);        
        $this->call(ConceptoCanceladoTableSeeder::class); 
        $this->call(CreditoAFavorTableSeeder::class);
        // $this->call(CreditoAplicadoTableSeeder::class);        
        // $this->call(DescuentoAplicadoTableSeeder::class);        
    }
}
