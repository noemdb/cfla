<?php

use Illuminate\Database\Seeder;

class IngresoFraccionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
