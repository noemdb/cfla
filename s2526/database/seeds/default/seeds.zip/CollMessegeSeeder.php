<?php

use Illuminate\Database\Seeder;

class CollMessegeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
