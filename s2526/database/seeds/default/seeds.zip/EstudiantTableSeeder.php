<?php

use Illuminate\Database\Seeder;

class EstudiantTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $file = "estudiants";
        $fecha = "2019-09-21-2";
        $csvFile = public_path().'/csv/'.$fecha.'/'.$file.'.csv';
        $arr_data = csv_to_array($csvFile,",");
        DB::table($file)->insert($arr_data);
    }
}
