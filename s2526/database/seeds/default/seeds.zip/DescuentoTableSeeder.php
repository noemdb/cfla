<?php

use Illuminate\Database\Seeder;

class DescuentoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        DB::table('descuentos')->insert([
            'descuento_name' => "BECA 3 HERMANOS",
            'descuento_description' => "GRUPO DE TRES (3) HERMANOS",
            'descuento_observations' => "",
            'descuento_type' => 'Porcentaje',
            'descuento_ammount' => 30.00,
        ]);
        DB::table('descuentos')->insert([
            'descuento_name' => "BECA BUEN PROMEDIO",
            'descuento_description' => "BECA BUEN PROMEDIO",
            'descuento_observations' => "",
            'descuento_type' => 'Porcentaje',
            'descuento_ammount' => 30.00,
        ]);
        // DB::table('descuentos')->insert([
        //     'descuento_name' => "BECA COMPLETA",
        //     'descuento_description' => "BECA COMPLETA",
        //     'descuento_observations' => "",
        //     'descuento_type' => 'Porcentaje',
        //     'descuento_ammount' => 100,
        // ]);
        DB::table('descuentos')->insert([
            'descuento_name' => "BECA EMPLEADOS",
            'descuento_description' => "BECA EMPLEADOS",
            'descuento_observations' => "",
            'descuento_type' => 'Porcentaje',
            'descuento_ammount' => 30,
        ]);

    }
}
