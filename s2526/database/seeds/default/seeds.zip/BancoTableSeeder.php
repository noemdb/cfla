<?php

use Illuminate\Database\Seeder;

class BancoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('bancos')->insert([
            'institucion_id' =>'1',
            'name' => "CREDITOS A FAVOR",
            'number_id_bank' => "100",
            'number_acount_bank' => "0163-0246-51-2463000279",
            'description' => "INSTITUCIÓN CREDITOS A FAVOR",
            'logo' => "images/brand/bancos/logo_BT.jpg",
            'commission_POS_bank' => "0.00",
            'commission_IGTF_bank' => "0.00",
            'status_active_bank' => 'true'
        ]);
        DB::table('bancos')->insert([
            'institucion_id' =>'1',
            'name' => "BANCO DEL TESORO",
            'number_id_bank' => "338",
            'number_acount_bank' => "0163-0246-51-2463000279",
            'description' => "BANCO DEL TESORO - SAN FELIPE",
            'logo' => "images/brand/bancos/logo_BT.jpg",
            'commission_POS_bank' => "0.00",
            'commission_IGTF_bank' => "0.00",
            'status_active_bank' => 'true'
        ]);
        DB::table('bancos')->insert([
            'institucion_id' =>'1',
            'name' => "BANCARIBE",
            'number_id_bank' => "339",
            'number_acount_bank' => "0114-0270-40-2700047221",
            'description' => "BANCARIBE - SAN FELIPE",
            'logo' => "images/brand/bancos/logo_bc.png",
            'commission_POS_bank' => "0.00",
            'commission_IGTF_bank' => "0.00",
            'status_active_bank' => "false"
        ]);
        DB::table('bancos')->insert([
            'institucion_id' =>'1',
            'name' => "CREDITO AÑO ANTERIOR",
            'number_id_bank' => "368",
            'number_acount_bank' => "0114-0163-50-2000570167",
            'description' => "CREDITO AÑO ANTERIOR",
            'logo' => "images/brand/bancos/bank_default.png",
            'commission_POS_bank' => "0.00",
            'commission_IGTF_bank' => "0.00",
            'status_active_bank' => 'true'
        ]);
        DB::table('bancos')->insert([
            'institucion_id' =>'1',
            'name' => "PANDCO",
            'number_id_bank' => "392",
            'number_acount_bank' => "0111-0252-50-2300004522",
            'logo' => "images/brand/bancos/logo_p.png",
            'description' => "PANDCO - WEB",
            'commission_POS_bank' => "0.00",
            'commission_IGTF_bank' => "0.00",
            'status_active_bank' => 'true'
            ]);
    }
}
