<?php

use Illuminate\Database\Seeder;

class GradoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('grados')->insert([
            'pestudio_id' => '1',
            'name' => '1er GRADO',
            'description' => '1er GRADO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '1',
            'name' => '2do GRADO',
            'description' => '2do GRADO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '1',
            'name' => '3er GRADO',
            'description' => '3er GRADO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '1',
            'name' => '4to GRADO',
            'description' => '4to GRADO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '1',
            'name' => '5to GRADO',
            'description' => '5to GRADO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '1',
            'name' => '6to GRADO',
            'description' => '6to GRADO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '2',
            'name' => 'PRIMER AÑO',
            'description' => 'PRIMER AÑO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '2',
            'name' => 'SEGUNDO AÑO',
            'description' => 'SEGUNDO AÑO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '2',
            'name' => 'TERCER AÑO',
            'description' => 'TERCER AÑO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '2',
            'name' => 'CUARTO AÑO',
            'description' => 'CUARTO AÑO',
            'status_active' => 'true'
        ]);
        DB::table('grados')->insert([
            'pestudio_id' => '2',
            'name' => 'QUINTO AÑO',
            'description' => 'QUINTO AÑO',
            'status_active' => 'true'
        ]);
    }
}
