<?php

use Illuminate\Database\Seeder;

class PestudioTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('pestudios')->insert([
            'peducativo_id' => 2,
            'code' => '21000',
            'name' => 'EDUCACION PRIMARIA',
            'order' => 1,
            'description' => 'EDUCACION PRIMARIA',
            'description_aux' => '',
            'mention' => '',
            'status_build_promotion' => 'false',
            'title' => '',
            'scale' => '1',
            'profile' => 'Orientamos a los niños y niñas a fortalecer esencialmente valores de vida y convivencia comunitaria, esto sumado a las diferentes +reas de aprendizaje fundamentales para su desarrollo integral, haciendo especial +nfasis en la aplicaci+n de comunicaci+n, integraci+n y respeto a la diversidad humana y ambiental, considerando que la ni+ez es la tierra f+rtil para nosotros plantar el futuro. Nuestras acciones pedag+gicas tratan de modelar las percepciones como el aprender a conocer y aprender a hacer en contexto, aprender a vivir juntos (aprender a vivir con otros) y aprender a ser; con herramientas didacticamente adecuadas a la diversas edades y condiciones cognitivas de las ni+as y ni+os, adem+s de promover con las +reas complementarias la m+sica, la tecnolog+a y la inducci+n a otro idioma. Estas acciones nos permiten cultivar nuestro prop+sito de lograr estudiantes que: Compartan alegr+as y se relacione con todos los miembros de nuestra comunidad. Proyecten dinamismo y entusiasmo en actividades acad+micas, sociales y deportivas. Sean capaces de respetar y exigir respeto. Cumplan con sus responsabilidades como alumno, hijo, joven y ciudadano del país. Valoren la educación como principio de vida para el crecimiento personal.',
            'show_hr' => 'true',
            'status_a_cualitative' => 'false',
            'status_active' => 'true'
        ]);
        DB::table('pestudios')->insert([
            'peducativo_id' => 3,
            'code' => '31059',
            'name' => 'EDUCACION MEDIA GENERAL',
            'order' => 2,
            'description' => 'EDUCACION MEDIA GENERAL',
            'description_aux' => '',
            'mention' => '',
            'status_build_promotion' => 'false',
            'title' => 'BACHILLER',
            'scale' => '2',
            'profile' => 'En esta etapa enfocamos nuestra labor a consolidar valores esenciales con miras a la formación de ciudadanos potencialmente exitosos, conscientes de las herramientas comunicacionales, cient+fica y tecnol+gicas de esta era para el desarrollo sustentable. Impulsamos en procesos din+micos e innovadores para lograr educandos capaces de adaptarse con +xito a los desaf+os acad+micos y sociales que se presentan en los diversos contextos. Nuestro deber es consolidar estudiantes que tengan la formaci+n para: Formamos alumnos que: Sean aut+nticos en su comportamiento. Proporcionen soluciones a las dificultades que se les presentan a diario. Acaten y definan normas en beneficio de la sociedad. No se conformen con un +xito ni se rindan con un fracaso. Valoren y disfruten las manifestaciones deportivas, cient+ficas, literarias y art+sticas. Sean anal+ticos, cr+ticos, cultos, reflexivos y comprometidos con sus acciones en la sociedad. Se desarrolle independiente, aut+nomo, acad+mica y socialmente bajo la pluralidad y el respeto. Sean conscientes de que la educaci+n es un proceso que se fortalece todos los d+as y de vital importancia para el desarrollo integral del ser humano.',
            'show_hr' => 'true',
            'status_a_cualitative' => 'false',
            'status_active' => 'true'
        ]);
        DB::table('pestudios')->insert([
            'peducativo_id' => 3,
            'code' => '32011',
            'name' => 'EDUCACION MEDIA GENERAL',
            'order' => 3,
            'description' => 'EDUCACION MEDIA GENERAL',
            'description_aux' => '',
            'mention' => '',
            'status_build_promotion' => 'false',
            'title' => 'BACHILLER',
            'scale' => '3',
            'profile' => '',
            'show_hr' => 'true',
            'status_a_cualitative' => 'false',
            'status_active' => 'false'
        ]);
    }
}


