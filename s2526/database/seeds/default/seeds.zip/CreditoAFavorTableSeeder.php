<?php

use Illuminate\Database\Seeder;

class CreditoAFavorTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $file = "credito_a_favors";
        $fecha = "2019-09-23";
        $csvFile = public_path().'/csv/'.$fecha.'/'.$file.'.csv';
        $arr_data = csv_to_array($csvFile,",");
        DB::table($file)->insert($arr_data);

        $file = "credito_a_favors";
        $fecha = "2019-09-23-2";
        $csvFile = public_path().'/csv/'.$fecha.'/'.$file.'.csv';
        $arr_data = csv_to_array($csvFile,",");
        DB::table($file)->insert($arr_data);
    }
}
