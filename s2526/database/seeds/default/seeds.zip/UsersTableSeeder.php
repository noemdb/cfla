<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // factory(App\User::class)->times(15)->create();

        // static $password;

        $id = DB::table('users')->insertGetId([
            'username' => "admin",
            'password' => bcrypt('clave01'),
            'email' => "admin@admin.com",
            'is_active' => 'enable',
            'created_at'=> Carbon::now(),
            'remember_token' => str_random(10),
        ]);

        DB::table('profiles')->insert([
            'firstname' => "Administrador",
            'lastname' => "del Sistema",
            'url_img' => "images/avatar/default_user_admin.png",
            'user_id' => $id,
            'created_at' => Carbon::now(),
        ]);

        DB::table('rols')->insert([
            'area' => "SISTEMA",
            'rol' => "ADMINISTRADOR",            
            'descripcion' => "webmaster del sistema",
            'finicial' => "20000101",
            'ffinal' => "21000101",
            'user_id' => $id,
            'created_at' => Carbon::now(),
        ]);

        // static $password;
        $id = DB::table('users')->insertGetId([
            'username' => "mbarrios",
            'password' => bcrypt('mbarrios'),
            'email' => "mbarrios@saefl.com",
            'is_active' => 'enable',
            'remember_token' => str_random(10),
            'created_at' => Carbon::now(),
        ]);

        DB::table('profiles')->insert([
            'firstname' => "María",
            'lastname' => "Barrios",
            'url_img' => "images/avatar/user_default.png",
            'user_id' => $id,
            'created_at' => Carbon::now(),
        ]);

        DB::table('rols')->insert([
            'area' => "ADMINISTRACIÓN",
            'rol' => "ASISTENTE",            
            'descripcion' => "Asistente Administrativo",
            'finicial' => "20190901",
            'ffinal' => "20200901",
            'user_id' => $id,
            'created_at' => Carbon::now(),
        ]);

        // static $password;
        $id = DB::table('users')->insertGetId([
            'username' => "lveliz",
            'password' => bcrypt('lveliz'),
            'email' => "lveliz@saefl.com",
            'is_active' => 'enable',
            'created_at' => Carbon::now(),
            'remember_token' => str_random(10),
            
        ]);

        DB::table('profiles')->insert([
            'firstname' => "LIDOSKA BEATRIZ",
            'lastname' => "VELIZ DUDAMEL",
            'url_img' => "images/avatar/user_default.png",
            'user_id' => $id,
            'created_at' => Carbon::now(),
        ]);

        DB::table('rols')->insert([
            'area' => "CONTROL ESTUDIO",
            'rol' => "COORDINADOR",            
            'descripcion' => "Coordinado/Jefe Control de Estudio",
            'finicial' => "20190901",
            'ffinal' => "20200901",
            'user_id' => $id,
            'created_at' => Carbon::now(),
        ]);

        $id = DB::table('users')->insertGetId([
            'username' => "mebarrios",
            'password' => bcrypt('mebarrios'),
            'email' => "mebarrios@saefl.com",
            'is_active' => 'enable',
            'created_at' => Carbon::now(),
            'remember_token' => str_random(10),
            
        ]);

        DB::table('profiles')->insert([
            'firstname' => "MARIA ENERDA",
            'lastname' => "BARRIOS OCHOA",
            'url_img' => "images/avatar/user_default.png",
            'user_id' => $id,
            'created_at' => Carbon::now(),
        ]);

        DB::table('rols')->insert([
            'area' => "ADMINISTRACIÓN",
            'rol' => "DIRECTOR",            
            'descripcion' => "DIRECTOR DE ADMINISTRACIÓN",
            'finicial' => "20190901",
            'ffinal' => "20200901",
            'user_id' => $id,
            'created_at' => Carbon::now(),
        ]);
    }
}
