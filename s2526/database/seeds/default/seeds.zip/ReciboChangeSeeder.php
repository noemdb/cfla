<?php

use Illuminate\Database\Seeder;

class ReciboChangeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
