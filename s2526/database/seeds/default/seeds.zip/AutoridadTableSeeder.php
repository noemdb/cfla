<?php

use Illuminate\Database\Seeder;

class AutoridadTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('autoridads')->insert([
            'tipo_id' =>'1',
            'institucion_id' =>'1',
            'pescolar_id' => "1",
            'name' => "THAIS",
            'lastname' => "UZCATEGUI DE PARRA",
            'ci' => "4321428",
            'position' => "DIRECTORA",
            'profile_professional' => "LIC.",
            'photo' => "../cfg/img/NzB4NzA/dpm.jpg",
            'finicial' => "2019-08-01",
            'ffinal' => "2020-07-31"
            ]);
        
        DB::table('autoridads')->insert([
            'tipo_id' =>'2',
            'institucion_id' =>'1',
            'pescolar_id' => "1",
            'name' => "EZEQUIEL JOSE",
            'lastname' => "SIERRA RODRIGUEZ",
            'ci' => "10000000",
            'position' => "ADMINISTRADOR",
            'profile_professional' => "LIC.",
            'photo' => "../cfg/img/NzB4NzA/dpm.jpg",
            'finicial' => "2019-08-01",
            'ffinal' => "2020-07-31"
        ]);

        DB::table('autoridads')->insert([
            'tipo_id' =>'3',
            'institucion_id' =>'1',
            'pescolar_id' => "1",
            'name' => "LIDOSKA BEATRIZ",
            'lastname' => "VELIZ DUDAMEL",
            'ci' => "10000000",
            'position' => "JEFE DE CONTROL DE ESTUDIO",
            'profile_professional' => "LIC.",
            'photo' => "../cfg/img/NzB4NzA/dpm.jpg",
            'finicial' => "2019-08-01",
            'ffinal' => "2020-07-31"
        ]);
        DB::table('autoridads')->insert([
            'tipo_id' =>'4',
            'institucion_id' =>'1',
            'pescolar_id' => "1",
            'name' => "MARIA ENERDA",
            'lastname' => "BARRIOS OCHOA",
            'ci' => "20000000",
            'position' => "DIRECTOR DE ADMINISTRACIÓN",
            'profile_professional' => "LIC.",
            'photo' => "../cfg/img/NzB4NzA/dpm.jpg",
            'finicial' => "2019-08-01",
            'ffinal' => "2020-07-31"
        ]);
    }
}
