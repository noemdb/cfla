<?php

use Illuminate\Database\Seeder;

class ConceptoCanceladoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $file = "concepto_cancelados";
        $fecha = "2019-09-21";
        $csvFile = public_path().'/csv/'.$fecha.'/'.$file.'.csv';
        $arr_data = csv_to_array($csvFile,",");
        DB::table($file)->insert($arr_data);
    }
}
