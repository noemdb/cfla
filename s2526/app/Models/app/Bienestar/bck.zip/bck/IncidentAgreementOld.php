<?php

namespace App\Models\app\Bienestar;

use App\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IncidentAgreementOld extends Model //incident_agreements
{
    use HasFactory;
    protected $fillable = [
        'user_id','incident_id','description','observations','status_notify_agreement','date_notify_email'
    ];

    const COLUMN_COMMENTS = [
        'user_id'=>'Usuario',
        'incident_id'=>'Incidencia',
        'description'=>'Descripción',
        'observations'=>'Observaciones',
        'status_notify_agreement'=>'Notificado',
        'date_notify_email'=>'Fecha de la Notifición',
        'status_close' => 'Incidente cerrado',
        'close_observations' => 'Observación de cierre',
        'status_notify_close' => 'Notificación de Incidente cerrado',
    ];

    public static function list_type()
    {
        return IncidentReason::all()->pluck('name','id') ;
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function incident()
    {
        return $this->belongsTo(Incident::class);
    }
}

/*
'incident_id','description','observations'
incident_id
description
observations

incident_id,description,observations,
incident_id
description
observations
*/
