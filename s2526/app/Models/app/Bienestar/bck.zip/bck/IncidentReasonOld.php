<?php

namespace App\Models\app\Bienestar;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class IncidentReasonOld extends Model
{
    use HasFactory;
    protected $fillable = [
        'name','status_valoration','category'
    ];

    const COLUMN_COMMENTS = [
        'name'=>'Nombre',
        'status_valoration'=>'Valoración',
        'category'=>'Categoría',
    ];

    public function incident()
    {
        return $this->hasMany(Incident::class,'reason_id');
    }

    public static function list_reason()
    {
        return IncidentReason::all()->pluck('name','id') ;
    }

    public static function list_reason_category($valoration=null, $ambit=null)
    {
        $reasons = DB::table('incident_reasons')
            ->select('incident_reasons.*')
            ->join('incident_descriptions', 'incident_reasons.id', '=', 'incident_descriptions.reason_id')
            ;
        $reasons = ( isset($valoration) ) ? $reasons->where('incident_reasons.status_valoration',$valoration) : $reasons ;

        $reasons = ( isset($ambit) ) ? $reasons->where('incident_descriptions.ambit',$ambit) : $reasons ;

        $reasons = $reasons->OrderBy('category')->get();

        $arr = Array();
        foreach ($reasons as $reason) {
            $arr[$reason->category][$reason->id] = $reason->name;
        }
        return $arr ;
    }

    // public static function list_reason_ambit($valoration=null)
    // {
    //     $reasons = DB::table('incident_reasons')
    //         ->select('incident_reasons.*');

    //     $reasons = ( $valoration === true || $valoration === false ) ? $reasons->where('status_valoration',$valoration) : $reasons ;

    //     $reasons = $reasons->OrderBy('category')->get();

    //     $arr = Array();
    //     foreach ($reasons as $reason) {
    //         $arr[$reason->category][$reason->id] = $reason->name;
    //     }
    //     return $arr ;
    // }

}

