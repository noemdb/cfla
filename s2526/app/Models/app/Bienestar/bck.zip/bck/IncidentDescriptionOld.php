<?php

namespace App\Models\app\Bienestar;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class IncidentDescriptionOld extends Model
{
    use HasFactory;
    protected $fillable = [
        'reason_id','name','ambit'
    ];

    const COLUMN_COMMENTS = [
        'name'=>'Nombre',
        'ambit'=>'Ámbito',
        'reason_id'=>'Motivo',
    ];

    public function incident_reason()
    {
        return $this->belongsTo(IncidentReason::class,'reason_id');
    }

    public static function list_description_tab($status_valoration=null, $ambit=null, $reason_id=null)
    {
        $descriptions = DB::table('incident_descriptions')
        ->select('incident_descriptions.*','incident_reasons.category as category')
        ->join('incident_reasons', 'incident_reasons.id', '=', 'incident_descriptions.reason_id');

        $descriptions = (isset($status_valoration)) ? $descriptions->where('incident_reasons.status_valoration',$status_valoration) : $descriptions;
        $descriptions = (isset($ambit)) ? $descriptions->where('incident_descriptions.ambit',$ambit) : $descriptions;
        $descriptions = (isset($reason_id)) ? $descriptions->where('incident_descriptions.reason_id',$reason_id) : $descriptions;

        $descriptions = $descriptions->get();

        $arr = Array();
        foreach ($descriptions as $description) {
            $arr[$description->category][$description->name] = $description->name;
        }
        return $arr;
    }

    public function getIncidentsAttribute()
    {
        $incidents = Incident::where('description',$this->name)->get();
        return $incidents;
    }

    public function getStatusActiveAttribute()
    {
        // return ( $this->status_default || $this->incidents->count() ) ? true : false ;
        return ( $this->incidents->count() ) ? true : false ;
    }

    public function getStatusDefaultAttribute()
    {
        return ( $this->id <= 116 ) ? true : false ;
    }
}
